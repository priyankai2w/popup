<?php if ( ! empty( $settings->height ) ) : ?>
.fl-node-<?php echo $id; ?> .fl-slideshow-container {
	height: <?php echo $settings->height; ?>px;
}
<?php endif; ?>