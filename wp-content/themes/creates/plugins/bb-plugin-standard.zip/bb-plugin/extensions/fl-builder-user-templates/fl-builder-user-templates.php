<?php

// Defines
define( 'FL_BUILDER_USER_TEMPLATES_DIR', FL_BUILDER_DIR . 'extensions/fl-builder-user-templates/' );
define( 'FL_BUILDER_USER_TEMPLATES_URL', FL_BUILDER_URL . 'extensions/fl-builder-user-templates/' );

// Classes
require_once FL_BUILDER_USER_TEMPLATES_DIR . 'classes/class-fl-builder-user-templates.php';
require_once FL_BUILDER_USER_TEMPLATES_DIR . 'classes/class-fl-builder-user-templates-admin.php';